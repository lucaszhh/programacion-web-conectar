function escribimensaje(){

    if (confirm("¿te gusta la coca?")) {
        alert("que bueno ahora dame comida que tengo hambre :D")
      
        
    }
    
    else{
        alert("andate no tas vienvenido >:( ")
    }
}